package com.example.assment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
