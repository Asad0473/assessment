

class AppUrl {


  static var baseUrl = 'https://randomuser.me' ;
static var userListEndpoint= "$baseUrl/api/"  ;



}