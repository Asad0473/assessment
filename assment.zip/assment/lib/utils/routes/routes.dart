

import 'package:assment/utils/routes/routes_name.dart';
import 'package:assment/view/dating_screen/dating_screen.dart';
import 'package:flutter/material.dart';

import '../../view/splash_screen/splash_view.dart';


class Routes {

  static Route<dynamic>  generateRoute(RouteSettings settings){

    switch(settings.name){
      case RoutesName.splash:
        return MaterialPageRoute(builder: (BuildContext context) => const SplashView());

      case RoutesName.home:
        return MaterialPageRoute(builder: (BuildContext context) =>  const DatingScreen());



      default:
        return MaterialPageRoute(builder: (_){
          return const Scaffold(
            body: Center(
              child: Text('No route defined'),
            ),
          );
        });

    }
  }
}