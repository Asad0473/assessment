

class RoutesName {

  static const String splash = 'splash_view' ;

  static const String datingList="dating_list";
  //home screen routes name
  static const String home = 'home_sceen' ;



}