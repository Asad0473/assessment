import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../data/response/status.dart';
import '../../utils/utils.dart';
import '../../view_model/dating_view_model.dart';
import 'components/dating_card.dart';


class DatingScreen extends StatefulWidget {
  const DatingScreen({super.key});

  @override
  _DatingScreenState createState() => _DatingScreenState();
}

class _DatingScreenState extends State<DatingScreen> {

  DatingListViewModel  datingViewModel = DatingListViewModel();
  
  @override
  void initState() {
    // TODO: implement initState
    datingViewModel.fetchDatingListApi();
    super.initState();
  }

  @override
  void dispose() {
    datingViewModel.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
        appBar: AppBar(
          title: const Text('Dating List'),
          backgroundColor: Colors.purple,
        ),
      body: ChangeNotifierProvider<DatingListViewModel>(
        create: (BuildContext context) => datingViewModel,
        child: Consumer<DatingListViewModel>(
            builder: (context, provider, _){
              switch(provider.userList.status){

                case Status.LOADING:
                  return const Center(child: CircularProgressIndicator());
                case Status.ERROR:
                  return Center(child: Text(provider.userList.message.toString()));
                case Status.COMPLETED:
                  return Column(
                    children: [
                      TextField(
                        decoration: InputDecoration(
                          hintText: 'Search',
                          prefixIcon: const Icon(Icons.search),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30.0),
                          ),
                          filled: true,
                          fillColor: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Expanded(
                        child: NotificationListener(
                          onNotification:(ScrollNotification scrollInfo){
if(scrollInfo.metrics.pixels==scrollInfo.metrics.maxScrollExtent && !provider.isLoading){
  provider.fetchDatingListApi();
}
return false;
                          } ,
                          child: ListView.builder(
                              itemCount:provider.getUserData.length +(provider.hasMore?1:0) ,
                              itemBuilder: (context,index){
                                if(index==provider.getUserData.length){
                                  return const Center(child: CircularProgressIndicator());
                                }
                                final data=provider.getUserData[index];
                            return  DatingCard(
                              type: data.name!.title!,
                              name: data.name!.first!,
                              age: data.dob!.age!,
                              distance: data.location!.timezone!.description!,
                              date: data.dob!.date!,
                              location: data.location!.street!.name!,
                              picture: data.picture!.medium!,
                            );
                          }),
                        ),
                      ),
                    ],
                  );

                case null:
                  // TODO: Handle this case.
              }
              return Container();
            }),
      ) ,
    );
  }
}
