
import 'package:flutter/material.dart';

class DatingCard extends StatelessWidget {
  final String type;
  final String name;
  final int age;
  final String distance;
  final String date;
  final String location;
  final String picture;

  const DatingCard({super.key,
    required this.type,
    required this.name,
    required this.age,
    required this.distance,
    required this.date,
    required this.location,
    required this.picture,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              type,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 5),
            Row(
              children: [
                 CircleAvatar(
                  backgroundImage: NetworkImage(picture),
                ),
                const SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$name - $age',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(distance),
                  ],
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.message),
                  onPressed: () {},
                ),
                IconButton(
                  icon: const Icon(Icons.call),
                  onPressed: () {},
                ),
              ],
            ),
            const SizedBox(height: 5),
            Row(
              children: [
                const Icon(Icons.calendar_today),
                const SizedBox(width: 5),
                Text(date),
              ],
            ),
            const SizedBox(height: 5),
            Row(
              children: [
                const Icon(Icons.location_on),
                const SizedBox(width: 5),
                Text(location),
              ],
            ),
          ],
        ),
      ),
    );
  }
}