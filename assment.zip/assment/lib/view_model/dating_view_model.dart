

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import '../data/response/api_response.dart';
import '../model/user_list_model.dart';
import '../respository/dating_repository.dart';


class DatingListViewModel with ChangeNotifier {

  final _myRepo = DatingRepository();

  ApiResponse<UserListModel> userList = ApiResponse.loading();
  List<Results>_userResult=[];
 List<Results> get getUserData=>_userResult;
    int page=1;
    int limit=10;
    bool _isloading=false;
    bool get isLoading=>_isloading;
      bool hasMore=true;

  setUserList(ApiResponse<UserListModel> response){
    print("response$response");
    userList = response ;

   // _userResult=response.data!.results!;
    notifyListeners();
  }




  Future<void> fetchDatingListApi ()async{
    try{
      if(_isloading || !hasMore) return;
      _isloading=true;
      notifyListeners();
      setUserList(ApiResponse.loading());


       _myRepo.fetchDatingUserList(page: page,result: limit).then((value){
        var data=setUserList(ApiResponse.completed(value));

        List<Results>userData  =data.results!;
        if(userData.isEmpty){
           hasMore=false;
        }
        else{
          _userResult.addAll(userData);

        }


      }).onError((error, stackTrace){

        setUserList(ApiResponse.error(error.toString()));

      });
    }
    catch (e){
if (kDebugMode) {
  print("error:$e");
}
_isloading=false;
notifyListeners();
    }
finally{
  _isloading=false;
  notifyListeners();
}
  }


}