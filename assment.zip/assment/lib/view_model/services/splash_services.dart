
import 'package:flutter/material.dart';
import '../../utils/routes/routes_name.dart';


class SplashServices {

  void moveToHome(BuildContext context)async{

    await  Future.delayed(const Duration(seconds: 3));
    Navigator.pushNamed(context, RoutesName.home);

  }



}