


import '../data/network/BaseApiServices.dart';
import '../data/network/NetworkApiService.dart';
import '../model/user_list_model.dart';
import '../res/app_url.dart';

class DatingRepository {

  final BaseApiServices _apiServices = NetworkApiService() ;

  Future<UserListModel> fetchDatingUserList({required int page, required int result})async{

    try{

      dynamic response = await _apiServices.getGetApiResponse("${AppUrl.userListEndpoint}?page=$page&results=$result");
      print("response Data$response");
      return response = UserListModel.fromJson(response);

    }catch(e){
      rethrow ;
    }
  }

}